package com.korchagin.java.courses.task6;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.korchagin.java.courses.task6"})
public class Task6Config {
}
