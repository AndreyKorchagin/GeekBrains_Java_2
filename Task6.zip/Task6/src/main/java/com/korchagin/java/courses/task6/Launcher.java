package com.korchagin.java.courses.task6;

import com.korchagin.java.courses.task6.services.GoodsService;
import com.korchagin.java.courses.task6.services.UsersService;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.webapp.WebAppContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.net.URL;
import java.security.ProtectionDomain;

public class Launcher {
    public static void main(String[] args) throws Exception {

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Task6Config.class);

        DBSession dbs = context.getBean("dbs", DBSession.class);

        PrepareDataApp.forcePrepareData(dbs);

//        UsersService usersService = context.getBean("usersService", UsersService.class);
//        GoodsService goodsService = context.getBean("goodsService", GoodsService.class);

        Server server = new Server(8189);

        ProtectionDomain domain = Launcher.class.getProtectionDomain();
        URL location = domain.getCodeSource().getLocation();

        WebAppContext webAppContext = new WebAppContext();
        webAppContext.setContextPath("/app");
        webAppContext.setWar(location.toExternalForm());

        server.setHandler(webAppContext);
        server.start();
        server.join();
        dbs.closeSession();
        context.close();
    }
}
